var controls;
(function (controls) {
    controls.jumping = false;
    controls.left = false;
    controls.right = false;
    controls.rTally = 0;
    controls.lTally = 0;
})(controls || (controls = {}));

//# sourceMappingURL=controls.js.map
