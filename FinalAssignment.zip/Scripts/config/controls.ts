﻿module controls {
    export var jumping: boolean = false;
    export var left: boolean = false;
    export var right: boolean = false;
    export var rTally: number = 0;
    export var lTally: number = 0;
} 